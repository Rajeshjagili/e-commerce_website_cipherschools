import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import LanusTechApp from './LanusTechApp';

ReactDOM.render(<LanusTechApp />, document.getElementById('root'));
